const mongoose = require('mongoose');

var Data = mongoose.model('Data', {
    plane_id: { 
        type: String
    },
    r_time: { 
        type: String 
    },
    fuel: { 
        type: String 
    },
    status:{ 
        type: String 
    }
});

module.exports = { Data };